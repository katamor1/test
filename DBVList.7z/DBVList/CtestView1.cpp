﻿// DBVListView.cpp : implementation of the CDBVListView class
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "DBVList.h"
#include "DBVListSet.h"
#include "DBVListDoc.h"
#include "CtestView1.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// CtestView1

IMPLEMENT_DYNCREATE(CtestView1, CFormView)

BEGIN_MESSAGE_MAP(CtestView1, CFormView)
	//{{AFX_MSG_MAP(CDBVListView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CtestView1::CtestView1()
	: CFormView(IDD_CtestView1)
{

}

CtestView1::~CtestView1()
{
}

void CtestView1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}


// CtestView1 診断

#ifdef _DEBUG
void CtestView1::AssertValid() const
{
	CFormView::AssertValid();
}

void CtestView1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CDBVListDoc* CtestView1::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDBVListDoc)));
	return (CDBVListDoc*)m_pDocument;
}
#endif //_DEBUG

