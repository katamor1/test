// DBVListView.cpp : implementation of the CDBVListView class
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "DBVList.h"

#include "DBVListSet.h"
#include "DBVListDoc.h"
#include "DBVListView.h"
#include "MainFrm.h"
#include "EmpView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBVListView

IMPLEMENT_DYNCREATE(CDBVListView, CFormView)

BEGIN_MESSAGE_MAP(CDBVListView, CFormView)
	//{{AFX_MSG_MAP(CDBVListView)
	ON_BN_CLICKED(IDC_FETCH, OnFetch)
	ON_EN_UPDATE(IDC_EDIT2, &CDBVListView::OnUpdateEdit2)
	ON_BN_CLICKED(IDC_BUTTON1, &CDBVListView::OnBnClickedButton1)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_DEL_SUBPANE, &CDBVListView::OnBnClickedDelSubpane)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CDBVListDialog, CDialog)
	ON_BN_CLICKED(IDC_TENKEY_0, &CDBVListDialog::OnTenkey0)
	ON_BN_CLICKED(IDC_TENKEY_1, &CDBVListDialog::OnTenkey1)
	ON_BN_CLICKED(IDC_TENKEY_2, &CDBVListDialog::OnTenkey2)
	ON_BN_CLICKED(IDC_TENKEY_3, &CDBVListDialog::OnTenkey3)
	ON_BN_CLICKED(IDC_TENKEY_4, &CDBVListDialog::OnTenkey4)
	ON_BN_CLICKED(IDC_TENKEY_5, &CDBVListDialog::OnTenkey5)
	ON_BN_CLICKED(IDC_TENKEY_6, &CDBVListDialog::OnTenkey6)
	ON_BN_CLICKED(IDC_TENKEY_7, &CDBVListDialog::OnTenkey7)
	ON_BN_CLICKED(IDC_TENKEY_8, &CDBVListDialog::OnTenkey8)
	ON_BN_CLICKED(IDC_TENKEY_9, &CDBVListDialog::OnTenkey9)
	ON_BN_CLICKED(IDC_TENKEY_E, &CDBVListDialog::OnTenkeyE)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CDBVListView construction/destruction

CDBVListView::CDBVListView()
	: CFormView(CDBVListView::IDD)
	, m_bDEL_SUBPANE(FALSE)
{
	//{{AFX_DATA_INIT(CDBVListView)
	m_pSet = NULL;
	m_strDiv = _T("");
	//}}AFX_DATA_INIT
}

CDBVListView::~CDBVListView()
{
}

void CDBVListView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDBVListView)
	DDX_CBString(pDX, IDC_DIV, m_strDiv);
	DDX_Text(pDX, IDC_EDIT2, m_strEdit);
	DDX_Text(pDX, IDC_STATIC1, static_cast<CString&>(m_pDBVlistDocument->m_strStatic));
	DDX_Text(pDX, IDC_NOW_TIME, m_strTime);
	DDX_Control(pDX, IDC_BLINK_IMG, m_blink_img);
	DDX_Check(pDX, IDC_DEL_SUBPANE, m_bDEL_SUBPANE);
	//}}AFX_DATA_MAP
}

BOOL CDBVListView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFormView::PreCreateWindow(cs);
}

void CDBVListView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_dBVListSet;
	m_pDBVlistDocument = GetDocument();

	m_blink_img_on.Load(_T("res\\bitmap1.bmp"));
	m_blink_img_off.Load(_T("res\\bitmap2.bmp"));

	UINT timerID = 1;

	UINT interval = 1000;

	SetTimer(timerID, interval, nullptr);

	timerID = 2;

	interval = 500;

	SetTimer(timerID, interval, nullptr);
	CFormView::OnInitialUpdate();
}

/////////////////////////////////////////////////////////////////////////////
// CDBVListView diagnostics

#ifdef _DEBUG
void CDBVListView::AssertValid() const
{
	CFormView::AssertValid();
}

void CDBVListView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CDBVListDoc* CDBVListView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDBVListDoc)));
	return (CDBVListDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDBVListView database support
CDaoRecordset* CDBVListView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CDBVListView message handlers

void CDBVListView::OnFetch()
{
	CMainFrame* pFrame=static_cast<CMainFrame*>(AfxGetMainWnd());
	CEmpView* pView=static_cast<CEmpView*>(pFrame->m_wndSplitter.GetPane(1,0));

	// set the filter for viewing the database to the currently selected division
	UpdateData(TRUE);
	pView->UpdateFilter(m_strDiv);
}

void CDBVListView::OnUpdateEdit2()
{
	UpdateData(TRUE);
	UpdateData(FALSE);
}

void CDBVListView::OnBnClickedButton1()
{
	this->GetDlgItem(IDC_EDIT2)->EnableWindow(TRUE);

	if (!m_DialogTenkey)
	{
		m_DialogTenkey = new CDBVListDialog(this);
		m_DialogTenkey->Create(IDD_TENKEY, this);
	}

	SetWindowPos(this->GetDlgItem(IDC_EDIT2), 0, 0, 0, 0, SWP_SHOWWINDOW | SWP_NOMOVE | SWP_NOSIZE);
	m_DialogTenkey->PostMessage(WM_UPDATEUISTATE, (UISF_HIDEFOCUS | UISF_HIDEACCEL | UISF_ACTIVE) << 16 | UIS_SET, 0);
	m_DialogTenkey->ShowWindow(SW_SHOWNOACTIVATE);
	this->GetDlgItem(IDC_EDIT2)->SetFocus();
}

void CDBVListView::OnTimer(UINT_PTR nIDEvent)
{
	UpdateData(TRUE);
	if( nIDEvent == 1)
	{
		m_strTime = CTime::GetCurrentTime().Format("%Y/%m/%d %H:%M:%S");
	}
	if (nIDEvent == 2)
	{
		if (m_blink_img_status)
		{
			m_blink_img.SetBitmap((HBITMAP)m_blink_img_on);
			m_blink_img_status = FALSE;
		}
		else
		{
			m_blink_img.SetBitmap((HBITMAP)m_blink_img_off);
			m_blink_img_status = TRUE;
		}
	}

	UpdateData(FALSE);
	CFormView::OnTimer(nIDEvent);
}

void CDBVListDialog::OnTenkey0()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '0', 0);
}

void CDBVListDialog::OnTenkey1()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '1', 0);
}

void CDBVListDialog::OnTenkey2()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '2', 0);
}

void CDBVListDialog::OnTenkey3()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '3', 0);
}

void CDBVListDialog::OnTenkey4()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '4', 0);
}

void CDBVListDialog::OnTenkey5()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '5', 0);
}

void CDBVListDialog::OnTenkey6()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '6', 0);
}

void CDBVListDialog::OnTenkey7()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '7', 0);
}

void CDBVListDialog::OnTenkey8()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '8', 0);
}

void CDBVListDialog::OnTenkey9()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	tmp->PostMessage(WM_KEYDOWN, '9', 0);
}

void CDBVListDialog::OnTenkeyE()
{
	CWnd* tmp = this->GetParent()->GetDlgItem(IDC_EDIT2);
	((CDBVListView*)this->GetParent())->m_pDBVlistDocument->m_strStatic = ((CDBVListView*)this->GetParent())->m_strEdit;
	((CDBVListView*)this->GetParent())->m_strEdit = "";
	this->GetParent()->UpdateData(FALSE);
	tmp->SetFocus();
	this->ShowWindow(SW_HIDE);
	this->GetParent()->GetDlgItem(IDC_EDIT2)->EnableWindow(FALSE);
}

void CDBVListView::OnBnClickedDelSubpane()
{
	CWnd* wnd = CWnd::GetActiveWindow();
	UpdateData(TRUE);
	UpdateData(FALSE);
	
	if (m_bDEL_SUBPANE)
	{
		wnd->PostMessage(WM_CHANGEPANESIZE, IDD_DBVLIST_FORM, MAIN_PANE_MAX);
	}
	else
	{
		wnd->PostMessage(WM_CHANGEPANESIZE, IDD_DBVLIST_FORM, MAIN_PANE_MIN);
	}
}
