// MainFrm.cpp : implementation of the CMainFrame class
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "DBVList.h"
#include "DBVListSet.h"
#include "DBVListDoc.h"
#include "DBVListView.h"
#include "CtestView1.h"

#include "MainFrm.h"
#include "EmpView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_MESSAGE(WM_CHANGEPANESIZE, OnChangePaneSize)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);

	return 0;
}

BOOL CMainFrame::OnCreateClient( LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
	if (!m_wndSplitter.CreateStatic(this,2,1))
	{
		TRACE0("Failed to create split bar ");
		return FALSE;    // failed to create
	}
	if (!m_wndSplitterSub.CreateStatic(&m_wndSplitter, 1, 2))
	{
		TRACE0("Failed to create split bar ");
		return FALSE;    // failed to create
	}
	if(!m_wndSplitter.CreateView(1,0,RUNTIME_CLASS(CEmpView),CSize(1000,400),pContext))
	{
		TRACE0("Failed to create CDBVListView ");
		return FALSE;    // failed to create
	}
	if (!m_wndSplitterSub.CreateView(0, 0, RUNTIME_CLASS(CDBVListView), CSize(600, 200), pContext))
	{
		TRACE0("Failed to create CDBVListView ");
		return FALSE;    // failed to create
	}
	if (!m_wndSplitterSub.CreateView(0, 1, RUNTIME_CLASS(CtestView1), CSize(400, 200), pContext))
	{
		TRACE0("Failed to create CEmpView ");
		return FALSE;    // failed to create
	}

	m_wndSplitterSub.SetColumnInfo(0, 600, 600);
	m_wndSplitterSub.SetColumnInfo(1, 400, 400);
	m_wndSplitter.SetRowInfo(0, 200, 200);
	m_wndSplitter.SetRowInfo(1, 400, 400);
	m_wndSplitter.RecalcLayout();
	m_wndSplitterSub.RecalcLayout();
	return TRUE;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.x = 200;
	cs.y = 200;
	cs.cx = 1050;
	cs.cy = 700;
	cs.style = WS_POPUP | WS_VISIBLE;

	return CFrameWnd::PreCreateWindow(cs);
}

LRESULT  CMainFrame::OnChangePaneSize(WPARAM wParam, LPARAM lParam)
{
	if (wParam == IDD_DBVLIST_FORM)
	{
		if (lParam == MAIN_PANE_MIN)
		{
			m_wndSplitterSub.SetColumnInfo(0, 600, 600);
			m_wndSplitterSub.SetColumnInfo(1, 400, 400);
			m_wndSplitterSub.RecalcLayout();
		}
		else if (lParam == MAIN_PANE_MAX)
		{
			m_wndSplitterSub.SetColumnInfo(0, 1100, 1100);
			m_wndSplitterSub.SetColumnInfo(1, 0, 0);
			m_wndSplitterSub.RecalcLayout();
		}
	}
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
