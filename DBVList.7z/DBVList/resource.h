//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// DBVList.rc �Ŏg�p
//
#define IDD_ABOUTBOX                    100
#define IDD_DBVLIST_FORM                101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDD_CtestView1                  104
#define IDR_MAINFRAME                   128
#define IDR_DBVLISTYPE                  129
#define IDB_BITMAP1                     132
#define IDD_TENKEY                      134
#define IDD_NUMCHECK_ERROR              136
#define IDB_BITMAP2                     138
#define IDB_BITMAP0                     139
#define IDC_DIV                         1000
#define IDC_FETCH                       1001
#define IDC_BUTTON1                     1002
#define IDC_PICT1                       1003
#define IDC_EDIT2                       1004
#define IDC_STATIC1                     1005
#define IDC_TENKEY_0                    1006
#define IDC_TENKEY_1                    1007
#define IDC_TENKEY_2                    1008
#define IDC_TENKEY_3                    1009
#define IDC_TENKEY_4                    1010
#define IDC_TENKEY_5                    1011
#define IDC_TENKEY_6                    1012
#define IDC_TENKEY_7                    1013
#define IDC_TENKEY_8                    1014
#define IDC_TENKEY_9                    1015
#define IDC_TENKEY_E                    1016
#define IDC_STATIC_MINVALUE             1020
#define IDC_STATIC_MAXVALUE             1021
#define IDC_NOW_TIME                    1022
#define IDC_BLINK_IMG                   1023
#define IDC_DEL_SUBPANE                 1030

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
