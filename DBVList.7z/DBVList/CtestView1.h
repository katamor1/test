﻿#pragma once


// CtestView1 フォーム ビュー

class CtestView1 : public CFormView
{
protected: // create from serialization only
	CtestView1();           // 動的生成で使用される protected コンストラクター
	DECLARE_DYNCREATE(CtestView1)

public:
	//{{AFX_DATA(CDBVListView)
	enum { IDD = IDD_CtestView1 };
	//}}AFX_DATA

// Attributes
public:
	CDBVListDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBVListView)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CtestView1();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDBVListView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.
