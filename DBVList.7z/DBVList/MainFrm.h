// MainFrm.h : interface of the CMainFrame class
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.
#include <afxcontrolbars.h>
#if !defined(AFX_MAINFRM_H__13CCB747_ED59_11D0_8286_00C04FD73634__INCLUDED_)
#define AFX_MAINFRM_H__13CCB747_ED59_11D0_8286_00C04FD73634__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
	class CSplitterFixWndEx : public CSplitterWndEx
	{
		virtual int HitTest(CPoint pt) const {
			(void)pt;
		return 0; }
		virtual void OnDrawSplitter(CDC* pDC,
			ESplitType nType,
			const CRect& rect
		){
			if(nType != ESplitType::splitBorder){
				CSplitterWndEx::OnDrawSplitter(pDC, nType, rect);
			}
		}
		
	};
	CSplitterFixWndEx m_wndSplitter;
	CSplitterFixWndEx m_wndSplitterSub;
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	LRESULT  OnChangePaneSize(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__13CCB747_ED59_11D0_8286_00C04FD73634__INCLUDED_)
